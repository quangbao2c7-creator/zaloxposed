# ZaloXposed v2.1 — by Quang Bảo
© 2026 Quang Bảo. Bảo lưu mọi quyền.

## Tính năng
- Menu viền 7 màu chuyển động, nút nổi Z kéo thả được.
- Viền 7 màu quanh toàn màn hình Zalo.
- Bảng thông tin: FPS, ngày giờ thực, RAM.
- Tắt Firebase Analytics, chặn theo tên miền (sửa danh sách trong menu).
- Nhật ký: xem, xuất, xóa.

## Build không cần Mac
Đẩy lên GitHub → Actions → "Build dylib" → tải artifact `ZaloXposed`.

## Mở menu
Bấm nút Z, hoặc chạm 2 lần bằng 3 ngón trong Zalo.


## Bản nâng cấp đang chuẩn bị
- Bổ sung màn hình nhận diện model thiết bị, tên iPhone, phiên bản iOS và IP IPv4 nội bộ (không gửi dữ liệu ra ngoài).
- Xem tin nhắn đã thu hồi và nhận diện chính xác avatar cần hook theo class nội bộ của từng bản Zalo; cần kiểm thử trên đúng phiên bản Zalo trước khi bật mặc định.
