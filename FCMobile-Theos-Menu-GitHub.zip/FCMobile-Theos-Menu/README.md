# FC Mobile UI Menu — Theos + GitHub Actions

Project này tạo một **menu giao diện minh hoạ** dạng floating bubble cho iOS. Các công tắc chỉ thay đổi trạng thái hiển thị của UI, không sửa gameplay, bộ nhớ, dữ liệu trận đấu, anti-cheat hoặc máy chủ.

## Build tự động bằng GitHub

1. Tạo repository GitHub mới.
2. Upload toàn bộ nội dung project này lên nhánh `main`.
3. Mở tab **Actions** và bật workflow nếu GitHub yêu cầu.
4. Chọn **Build FCMenu dylib** → **Run workflow**.
5. Mở lần chạy mới nhất, kéo xuống **Artifacts** và tải `FCMenu-dylib`.

Workflow cũng tự chạy khi push code lên `main`.

## Build cục bộ bằng Theos

Cài Theos và iPhoneOS SDK, sau đó chạy:

```sh
make clean
make
```

Dylib được Theos tạo trong thư mục `.theos/obj/` (đường dẫn con có thể thay đổi theo phiên bản Theos).

## Cấu trúc

```text
.
├── .github/workflows/build.yml
├── Makefile
├── control
├── FCMenu.plist
├── Tweak.xm
└── README.md
```

## Lưu ý

- `FCMenu.plist` dùng bundle identifier `com.ea.gp.fifamobile` làm cấu hình mục tiêu mẫu. Hãy xác minh bundle ID của bản game đang cài trước khi dùng trong môi trường thử nghiệm.
- Workflow build ra dylib dạng Theos tweak; GitHub Actions không tự cài hoặc inject dylib vào thiết bị.
- Không dùng project này để gian lận trong trận đấu hoặc can thiệp dịch vụ trực tuyến.
