#import <UIKit/UIKit.h>

static NSString * const kBubbleTag = @"com.example.fcmenu.bubble";
static NSString * const kPanelTag  = @"com.example.fcmenu.panel";

@interface FCMenuController : NSObject
@property (nonatomic, strong) UIWindow *hostWindow;
@property (nonatomic, strong) UIButton *bubble;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, assign) BOOL installed;
@end

@implementation FCMenuController

+ (instancetype)shared {
    static FCMenuController *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [FCMenuController new];
    });
    return instance;
}

- (UIWindow *)activeWindow {
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (scene.activationState != UISceneActivationStateForegroundActive) continue;
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        UIWindowScene *windowScene = (UIWindowScene *)scene;
        for (UIWindow *window in windowScene.windows) {
            if (window.isKeyWindow) return window;
        }
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    return UIApplication.sharedApplication.keyWindow;
#pragma clang diagnostic pop
}

- (void)installIfNeeded {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *window = [self activeWindow];
        if (!window || self.installed) return;
        self.hostWindow = window;
        [self buildBubble];
        self.installed = YES;
    });
}

- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)weight {
    UILabel *label = [UILabel new];
    label.text = text;
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont systemFontOfSize:size weight:weight];
    return label;
}

- (void)buildBubble {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(18, 170, 54, 54);
    button.layer.cornerRadius = 27;
    button.backgroundColor = [UIColor colorWithRed:0.10 green:0.43 blue:0.95 alpha:0.96];
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.35].CGColor;
    [button setTitle:@"FC" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    button.accessibilityLabel = @"Open FC menu";
    [button addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragBubble:)];
    [button addGestureRecognizer:pan];
    [self.hostWindow addSubview:button];
    self.bubble = button;
}

- (void)dragBubble:(UIPanGestureRecognizer *)gesture {
    UIView *view = gesture.view;
    CGPoint delta = [gesture translationInView:self.hostWindow];
    view.center = CGPointMake(view.center.x + delta.x, view.center.y + delta.y);
    [gesture setTranslation:CGPointZero inView:self.hostWindow];

    if (gesture.state == UIGestureRecognizerStateEnded) {
        CGFloat inset = 12;
        CGFloat x = MIN(MAX(view.center.x, view.bounds.size.width / 2 + inset),
                        self.hostWindow.bounds.size.width - view.bounds.size.width / 2 - inset);
        CGFloat y = MIN(MAX(view.center.y, view.bounds.size.height / 2 + 60),
                        self.hostWindow.bounds.size.height - view.bounds.size.height / 2 - 60);
        [UIView animateWithDuration:0.18 animations:^{
            view.center = CGPointMake(x, y);
        }];
    }
}

- (UISwitch *)demoSwitchWithTitle:(NSString *)title inView:(UIView *)container y:(CGFloat)y {
    UILabel *name = [self label:title size:14 weight:UIFontWeightMedium];
    name.frame = CGRectMake(16, y, 205, 34);
    [container addSubview:name];

    UISwitch *toggle = [UISwitch new];
    toggle.on = NO;
    toggle.transform = CGAffineTransformMakeScale(0.82, 0.82);
    toggle.frame = CGRectMake(222, y + 1, 52, 32);
    [toggle addTarget:self action:@selector(demoSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [container addSubview:toggle];
    return toggle;
}

- (void)demoSwitchChanged:(UISwitch *)sender {
    // Visual demo only. Switches intentionally do not modify game state.
    sender.onTintColor = [UIColor colorWithRed:0.12 green:0.62 blue:0.96 alpha:1];
}

- (void)buildPanel {
    UIView *panel = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 292, 286)];
    panel.backgroundColor = [UIColor colorWithRed:0.055 green:0.075 blue:0.12 alpha:0.97];
    panel.layer.cornerRadius = 16;
    panel.layer.borderWidth = 1;
    panel.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.16].CGColor;
    panel.clipsToBounds = YES;

    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 292, 58)];
    header.backgroundColor = [UIColor colorWithRed:0.08 green:0.20 blue:0.36 alpha:1];
    [panel addSubview:header];

    UILabel *title = [self label:@"FC MOBILE  •  UI MENU" size:15 weight:UIFontWeightBold];
    title.frame = CGRectMake(16, 0, 230, 58);
    [header addSubview:title];

    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(246, 10, 36, 36);
    [close setTitle:@"×" forState:UIControlStateNormal];
    [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:27 weight:UIFontWeightRegular];
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:close];

    UILabel *subtitle = [self label:@"Giao diện minh hoạ — không tác động gameplay" size:11 weight:UIFontWeightRegular];
    subtitle.textColor = [UIColor colorWithWhite:1 alpha:0.62];
    subtitle.frame = CGRectMake(16, 68, 260, 20);
    [panel addSubview:subtitle];

    [self demoSwitchWithTitle:@"Hiệu ứng giao diện" inView:panel y:102];
    [self demoSwitchWithTitle:@"Thông tin phiên bản" inView:panel y:146];
    [self demoSwitchWithTitle:@"Hiển thị trạng thái menu" inView:panel y:190];

    UILabel *footer = [self label:@"VISUAL DEMO  •  v1.0.0" size:10 weight:UIFontWeightSemibold];
    footer.textColor = [UIColor colorWithWhite:1 alpha:0.42];
    footer.textAlignment = NSTextAlignmentCenter;
    footer.frame = CGRectMake(12, 248, 268, 22);
    [panel addSubview:footer];

    panel.center = CGPointMake(CGRectGetMidX(self.hostWindow.bounds),
                               CGRectGetMidY(self.hostWindow.bounds));
    panel.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
                             UIViewAutoresizingFlexibleBottomMargin |
                             UIViewAutoresizingFlexibleLeftMargin |
                             UIViewAutoresizingFlexibleRightMargin;
    self.panel = panel;
}

- (void)togglePanel {
    if (!self.panel) [self buildPanel];
    if (self.panel.superview) {
        [UIView animateWithDuration:0.15 animations:^{
            self.panel.alpha = 0;
            self.panel.transform = CGAffineTransformMakeScale(0.96, 0.96);
        } completion:^(BOOL finished) {
            [self.panel removeFromSuperview];
            self.panel.alpha = 1;
            self.panel.transform = CGAffineTransformIdentity;
        }];
    } else {
        self.panel.alpha = 0;
        self.panel.transform = CGAffineTransformMakeScale(0.96, 0.96);
        [self.hostWindow addSubview:self.panel];
        [UIView animateWithDuration:0.18 animations:^{
            self.panel.alpha = 1;
            self.panel.transform = CGAffineTransformIdentity;
        }];
    }
}

@end

%ctor {
    @autoreleasepool {
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                                                          object:nil
                                                           queue:NSOperationQueue.mainQueue
                                                      usingBlock:^(__unused NSNotification *note) {
            [[FCMenuController shared] installIfNeeded];
        }];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            [[FCMenuController shared] installIfNeeded];
        });
    }
}
