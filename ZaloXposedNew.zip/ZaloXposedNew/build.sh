#!/bin/bash
set -e
rm -rf build && mkdir -p build
SDK=$(xcrun --sdk iphoneos --show-sdk-path)
xcrun -sdk iphoneos clang -arch arm64 -miphoneos-version-min=14.0 -isysroot "$SDK" \
  -fobjc-arc -dynamiclib -framework UIKit -framework Foundation -framework CoreGraphics \
  -install_name @rpath/ZaloXposed.dylib -o build/ZaloXposed.dylib src/Tweak.m
# Bundle chuỗi (tùy chọn)
B=build/ZaloXposedRes.bundle
mkdir -p $B && cp -R Resources/*.lproj $B/
cat > $B/Info.plist << 'PL'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.electroheavenvn.zaloxposed.res</string>
<key>CFBundleName</key><string>ZaloXposedRes</string>
<key>CFBundlePackageType</key><string>BNDL</string>
</dict></plist>
PL
ls -la build
