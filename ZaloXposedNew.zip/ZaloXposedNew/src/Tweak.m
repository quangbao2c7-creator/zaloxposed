// ZaloXposed (bản mới) - chặn theo dõi / quảng cáo bằng ObjC runtime thuần.
// Không phụ thuộc Substrate nên chèn được vào IPA (Sideloadly, TrollStore...).
#import <UIKit/UIKit.h>
#import <objc/runtime.h>

#pragma mark - Cấu hình

static NSString *const kPrefix = @"ZX_";

static NSArray<NSString *> *ZXDefaultHosts(void) {
    // Chỉ gồm máy chủ analytics công khai của Google/Firebase.
    // Muốn chặn thêm (vd. máy chủ quảng cáo) thì thêm trong màn hình cài đặt.
    return @[@"app-measurement.com", @"firebaselogging.googleapis.com",
             @"firebase-settings.crashlytics.com", @"crashlytics.com"];
}

static BOOL ZXBool(NSString *k, BOOL def) {
    id v = [[NSUserDefaults standardUserDefaults] objectForKey:[kPrefix stringByAppendingString:k]];
    return v ? [v boolValue] : def;
}
static void ZXSetBool(NSString *k, BOOL v) {
    [[NSUserDefaults standardUserDefaults] setBool:v forKey:[kPrefix stringByAppendingString:k]];
}
static NSArray<NSString *> *ZXHosts(void) {
    NSArray *a = [[NSUserDefaults standardUserDefaults] arrayForKey:@"ZX_hosts"];
    return a ?: ZXDefaultHosts();
}

#pragma mark - Chuỗi (đọc Localizable.strings nếu có bundle, không thì dùng mặc định)

static NSString *ZXL(NSString *key, NSString *fallback) {
    static NSBundle *b; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *p = [[NSBundle mainBundle] pathForResource:@"ZaloXposedRes" ofType:@"bundle"];
        b = p ? [NSBundle bundleWithPath:p] : nil;
    });
    return b ? [b localizedStringForKey:key value:fallback table:@"Localizable"] : fallback;
}

#pragma mark - Log

static NSString *ZXLogPath(void) {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *dir = [docs stringByAppendingPathComponent:@"ZaloXposed"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return [dir stringByAppendingPathComponent:@"log.txt"];
}

static void ZXLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
static void ZXLog(NSString *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    static dispatch_queue_t q; static dispatch_once_t once; static NSDateFormatter *df;
    dispatch_once(&once, ^{
        q = dispatch_queue_create("zx.log", DISPATCH_QUEUE_SERIAL);
        df = [NSDateFormatter new]; df.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    });
    dispatch_async(q, ^{
        NSString *line = [NSString stringWithFormat:@"%@ %@\n", [df stringFromDate:[NSDate date]], msg];
        NSString *path = ZXLogPath();
        if (![[NSFileManager defaultManager] fileExistsAtPath:path])
            [[NSFileManager defaultManager] createFileAtPath:path contents:nil attributes:nil];
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
        [h seekToEndOfFile];
        [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        [h closeFile];
    });
}

#pragma mark - Chặn mạng theo tên miền

@interface ZXBlockProtocol : NSURLProtocol @end
@implementation ZXBlockProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)r {
    if (!ZXBool(@"block_hosts", YES)) return NO;
    NSString *h = r.URL.host.lowercaseString;
    if (!h.length) return NO;
    for (NSString *b in ZXHosts()) {
        NSString *bl = b.lowercaseString;
        if (!bl.length) continue;
        if ([h isEqualToString:bl] || [h hasSuffix:[@"." stringByAppendingString:bl]]) return YES;
    }
    return NO;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)r { return r; }
- (void)startLoading {
    ZXLog(@"blocked: %@", self.request.URL.host);
    [self.client URLProtocol:self didFailWithError:
        [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil]];
}
- (void)stopLoading {}
@end

static void ZXPatchConfig(NSURLSessionConfiguration *c) {
    NSMutableArray *a = [NSMutableArray arrayWithObject:[ZXBlockProtocol class]];
    if (c.protocolClasses) [a addObjectsFromArray:c.protocolClasses];
    c.protocolClasses = a;
}

static NSURLSessionConfiguration *(*orig_default)(id, SEL);
static NSURLSessionConfiguration *new_default(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_default(s, c); ZXPatchConfig(x); return x;
}
static NSURLSessionConfiguration *(*orig_ephemeral)(id, SEL);
static NSURLSessionConfiguration *new_ephemeral(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_ephemeral(s, c); ZXPatchConfig(x); return x;
}

#pragma mark - Firebase Analytics

static void (*orig_fir_log)(id, SEL, NSString *, NSDictionary *);
static void new_fir_log(id self, SEL _cmd, NSString *name, NSDictionary *params) {
    if (ZXBool(@"disable_firebase", YES)) return;
    if (orig_fir_log) orig_fir_log(self, _cmd, name, params);
}

static void ZXInstallHooks(void) {
    static BOOL netDone = NO, firDone = NO;
    if (!netDone) {
        netDone = YES;
        [NSURLProtocol registerClass:[ZXBlockProtocol class]];
        Class cfg = [NSURLSessionConfiguration class];
        Method m1 = class_getClassMethod(cfg, @selector(defaultSessionConfiguration));
        if (m1) orig_default = (void *)method_setImplementation(m1, (IMP)new_default);
        Method m2 = class_getClassMethod(cfg, @selector(ephemeralSessionConfiguration));
        if (m2) orig_ephemeral = (void *)method_setImplementation(m2, (IMP)new_ephemeral);
        ZXLog(@"network hooks installed");
    }
    if (!firDone) {
        Class fir = objc_getClass("FIRAnalytics");
        if (fir) {
            Method m = class_getClassMethod(fir, @selector(logEventWithName:parameters:));
            if (m) {
                firDone = YES;
                orig_fir_log = (void *)method_setImplementation(m, (IMP)new_fir_log);
                ZXLog(@"FIRAnalytics hook installed");
            }
        }
    }
}

#pragma mark - Màn hình cài đặt

@interface ZXLogVC : UIViewController @end
@implementation ZXLogVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = ZXL(@"log_view", @"Xem nhật ký");
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    UITextView *tv = [[UITextView alloc] initWithFrame:self.view.bounds];
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tv.editable = NO;
    tv.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    NSString *t = [NSString stringWithContentsOfFile:ZXLogPath() encoding:NSUTF8StringEncoding error:nil];
    tv.text = t.length ? t : ZXL(@"log_empty", @"Chưa có nhật ký");
    [self.view addSubview:tv];
}
@end

@interface ZXSettingsVC : UITableViewController @end
@implementation ZXSettingsVC {
    NSArray *_toggles; NSArray *_actions;
}
- (instancetype)init {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    _toggles = @[
        @[@"disable_firebase", @"logging_disable_firebase", @"Tắt Firebase Analytics"],
        @[@"block_hosts", @"block_ads_endpoints", @"Chặn theo tên miền"],
    ];
    _actions = @[
        @[@"edit_hosts", @"block_ads_endpoints_desc", @"Sửa danh sách tên miền bị chặn"],
        @[@"log_view", @"log_view", @"Xem nhật ký"],
        @[@"log_export", @"log_export", @"Xuất nhật ký"],
        @[@"log_clear", @"log_clear", @"Xóa nhật ký"],
    ];
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = ZXL(@"settings_title", @"Cài đặt ZaloXposed");
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
        initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(close)];
}
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)t { return 2; }
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s {
    return s == 0 ? _toggles.count : _actions.count;
}
- (NSString *)tableView:(UITableView *)t titleForFooterInSection:(NSInteger)s {
    return s == 0 ? ZXL(@"restart_required", @"Cần khởi động lại Zalo để áp dụng thay đổi") : nil;
}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *c = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if (ip.section == 0) {
        NSArray *r = _toggles[ip.row];
        c.textLabel.text = ZXL(r[1], r[2]);
        UISwitch *sw = [UISwitch new];
        sw.on = ZXBool(r[0], YES);
        sw.tag = ip.row;
        [sw addTarget:self action:@selector(toggled:) forControlEvents:UIControlEventValueChanged];
        c.accessoryView = sw;
        c.selectionStyle = UITableViewCellSelectionStyleNone;
    } else {
        NSArray *r = _actions[ip.row];
        c.textLabel.text = [r[0] isEqualToString:@"edit_hosts"] ? r[2] : ZXL(r[1], r[2]);
        c.textLabel.textColor = self.view.tintColor;
    }
    return c;
}
- (void)toggled:(UISwitch *)sw {
    ZXSetBool(_toggles[sw.tag][0], sw.on);
    ZXLog(@"%@ = %d", _toggles[sw.tag][0], sw.on);
}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [t deselectRowAtIndexPath:ip animated:YES];
    if (ip.section != 1) return;
    NSString *a = _actions[ip.row][0];
    if ([a isEqualToString:@"edit_hosts"]) {
        UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"Tên miền bị chặn"
            message:@"Cách nhau bằng dấu phẩy" preferredStyle:UIAlertControllerStyleAlert];
        [ac addTextFieldWithConfigurationHandler:^(UITextField *tf) {
            tf.text = [ZXHosts() componentsJoinedByString:@","];
            tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
        }];
        [ac addAction:[UIAlertAction actionWithTitle:ZXL(@"button_cancel", @"Hủy") style:UIAlertActionStyleCancel handler:nil]];
        [ac addAction:[UIAlertAction actionWithTitle:ZXL(@"button_save", @"Lưu") style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
            NSMutableArray *out = [NSMutableArray array];
            for (NSString *s in [ac.textFields.firstObject.text componentsSeparatedByString:@","]) {
                NSString *h = [s stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
                if (h.length) [out addObject:h];
            }
            [[NSUserDefaults standardUserDefaults] setObject:out forKey:@"ZX_hosts"];
        }]];
        [self presentViewController:ac animated:YES completion:nil];
    } else if ([a isEqualToString:@"log_view"]) {
        [self.navigationController pushViewController:[ZXLogVC new] animated:YES];
    } else if ([a isEqualToString:@"log_export"]) {
        NSURL *u = [NSURL fileURLWithPath:ZXLogPath()];
        UIActivityViewController *vc = [[UIActivityViewController alloc] initWithActivityItems:@[u] applicationActivities:nil];
        vc.popoverPresentationController.sourceView = self.view;
        vc.popoverPresentationController.sourceRect = CGRectMake((self.view.bounds.size.width / 2), 100, 1, 1);
        [self presentViewController:vc animated:YES completion:nil];
    } else if ([a isEqualToString:@"log_clear"]) {
        [@"" writeToFile:ZXLogPath() atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
}
@end

#pragma mark - Cách mở cài đặt: chạm 2 lần bằng 3 ngón

static UIViewController *ZXTopVC(void) {
    UIWindow *w = nil;
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if ([s isKindOfClass:[UIWindowScene class]] && s.activationState == UISceneActivationStateForegroundActive) {
            for (UIWindow *x in ((UIWindowScene *)s).windows) if (x.isKeyWindow) { w = x; break; }
        }
    }
    UIViewController *v = w.rootViewController;
    while (v.presentedViewController) v = v.presentedViewController;
    return v;
}

@interface ZXTrigger : NSObject
+ (instancetype)shared; - (void)attach; - (void)open;
@end
@implementation ZXTrigger
+ (instancetype)shared { static ZXTrigger *t; static dispatch_once_t o; dispatch_once(&o, ^{ t = [ZXTrigger new]; }); return t; }
- (void)attach {
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (![s isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *w in ((UIWindowScene *)s).windows) {
            if (objc_getAssociatedObject(w, "zx_attached")) continue;
            UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(open)];
            g.numberOfTapsRequired = 2; g.numberOfTouchesRequired = 3; g.cancelsTouchesInView = NO;
            [w addGestureRecognizer:g];
            objc_setAssociatedObject(w, "zx_attached", @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }
}
- (void)open {
    UIViewController *top = ZXTopVC();
    if (!top || [top isKindOfClass:[UINavigationController class]] && [((UINavigationController *)top).viewControllers.firstObject isKindOfClass:[ZXSettingsVC class]]) return;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[ZXSettingsVC new]];
    [top presentViewController:nav animated:YES completion:nil];
}
@end

#pragma mark - Khởi tạo

__attribute__((constructor)) static void ZXInit(void) {
    ZXLog(@"ZaloXposed loaded in %@", NSBundle.mainBundle.bundleIdentifier);
    ZXInstallHooks();
    NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
    void (^again)(NSNotification *) = ^(NSNotification *n) {
        ZXInstallHooks();
        [[ZXTrigger shared] attach];
    };
    [nc addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
    [nc addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
}
