// ZaloXposed v2.1
// © 2026 Quang Bảo. Bảo lưu mọi quyền (All rights reserved).
// Chặn theo dõi, menu viền 7 màu, bảng FPS / giờ / RAM - bằng ObjC runtime thuần.
// Không phụ thuộc Substrate nên chèn được vào IPA (Sideloadly, TrollStore...).
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <mach/mach.h>

#pragma mark - Cấu hình

static NSString *const kPrefix = @"ZX_";

static NSArray<NSString *> *ZXDefaultHosts(void) {
    // Chỉ gồm máy chủ analytics công khai của Google/Firebase.
    // Muốn chặn thêm (vd. máy chủ quảng cáo) thì thêm trong màn hình cài đặt.
    return @[@"app-measurement.com", @"firebaselogging.googleapis.com",
             @"firebase-settings.crashlytics.com", @"crashlytics.com"];
}

static BOOL ZXBool(NSString *k, BOOL def) {
    id v = [[NSUserDefaults standardUserDefaults] objectForKey:[kPrefix stringByAppendingString:k]];
    return v ? [v boolValue] : def;
}
static void ZXSetBool(NSString *k, BOOL v) {
    [[NSUserDefaults standardUserDefaults] setBool:v forKey:[kPrefix stringByAppendingString:k]];
}
static NSArray<NSString *> *ZXHosts(void) {
    NSArray *a = [[NSUserDefaults standardUserDefaults] arrayForKey:@"ZX_hosts"];
    return a ?: ZXDefaultHosts();
}

#pragma mark - Chuỗi (đọc Localizable.strings nếu có bundle, không thì dùng mặc định)

static NSString *ZXL(NSString *key, NSString *fallback) {
    static NSBundle *b; static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSString *p = [[NSBundle mainBundle] pathForResource:@"ZaloXposedRes" ofType:@"bundle"];
        b = p ? [NSBundle bundleWithPath:p] : nil;
    });
    return b ? [b localizedStringForKey:key value:fallback table:@"Localizable"] : fallback;
}

#pragma mark - Log

static NSString *ZXLogPath(void) {
    NSString *docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *dir = [docs stringByAppendingPathComponent:@"ZaloXposed"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return [dir stringByAppendingPathComponent:@"log.txt"];
}

static void ZXLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);
static void ZXLog(NSString *fmt, ...) {
    if (!ZXBool(@"log_enabled", YES)) return;
    va_list ap; va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    static dispatch_queue_t q; static dispatch_once_t once; static NSDateFormatter *df;
    dispatch_once(&once, ^{
        q = dispatch_queue_create("zx.log", DISPATCH_QUEUE_SERIAL);
        df = [NSDateFormatter new]; df.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    });
    dispatch_async(q, ^{
        NSString *line = [NSString stringWithFormat:@"%@ %@\n", [df stringFromDate:[NSDate date]], msg];
        NSString *path = ZXLogPath();
        if (![[NSFileManager defaultManager] fileExistsAtPath:path])
            [[NSFileManager defaultManager] createFileAtPath:path contents:nil attributes:nil];
        NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
        [h seekToEndOfFile];
        [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
        [h closeFile];
    });
}

#pragma mark - Chặn mạng theo tên miền

@interface ZXBlockProtocol : NSURLProtocol @end
@implementation ZXBlockProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)r {
    if (!ZXBool(@"block_hosts", YES)) return NO;
    NSString *h = r.URL.host.lowercaseString;
    if (!h.length) return NO;
    for (NSString *b in ZXHosts()) {
        NSString *bl = b.lowercaseString;
        if (!bl.length) continue;
        if ([h isEqualToString:bl] || [h hasSuffix:[@"." stringByAppendingString:bl]]) return YES;
    }
    return NO;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)r { return r; }
- (void)startLoading {
    ZXLog(@"blocked: %@", self.request.URL.host);
    [self.client URLProtocol:self didFailWithError:
        [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorNotConnectedToInternet userInfo:nil]];
}
- (void)stopLoading {}
@end

static void ZXPatchConfig(NSURLSessionConfiguration *c) {
    NSMutableArray *a = [NSMutableArray arrayWithObject:[ZXBlockProtocol class]];
    if (c.protocolClasses) [a addObjectsFromArray:c.protocolClasses];
    c.protocolClasses = a;
}

static NSURLSessionConfiguration *(*orig_default)(id, SEL);
static NSURLSessionConfiguration *new_default(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_default(s, c); ZXPatchConfig(x); return x;
}
static NSURLSessionConfiguration *(*orig_ephemeral)(id, SEL);
static NSURLSessionConfiguration *new_ephemeral(id s, SEL c) {
    NSURLSessionConfiguration *x = orig_ephemeral(s, c); ZXPatchConfig(x); return x;
}

#pragma mark - Firebase Analytics

static void (*orig_fir_log)(id, SEL, NSString *, NSDictionary *);
static void new_fir_log(id self, SEL _cmd, NSString *name, NSDictionary *params) {
    if (ZXBool(@"disable_firebase", YES)) return;
    if (orig_fir_log) orig_fir_log(self, _cmd, name, params);
}

static void ZXInstallHooks(void) {
    static BOOL netDone = NO, firDone = NO;
    if (!netDone) {
        netDone = YES;
        [NSURLProtocol registerClass:[ZXBlockProtocol class]];
        Class cfg = [NSURLSessionConfiguration class];
        Method m1 = class_getClassMethod(cfg, @selector(defaultSessionConfiguration));
        if (m1) orig_default = (void *)method_setImplementation(m1, (IMP)new_default);
        Method m2 = class_getClassMethod(cfg, @selector(ephemeralSessionConfiguration));
        if (m2) orig_ephemeral = (void *)method_setImplementation(m2, (IMP)new_ephemeral);
        ZXLog(@"network hooks installed");
    }
    if (!firDone) {
        Class fir = objc_getClass("FIRAnalytics");
        if (fir) {
            Method m = class_getClassMethod(fir, @selector(logEventWithName:parameters:));
            if (m) {
                firDone = YES;
                orig_fir_log = (void *)method_setImplementation(m, (IMP)new_fir_log);
                ZXLog(@"FIRAnalytics hook installed");
            }
        }
    }
}

#pragma mark - Tiện ích giao diện

static UIWindow *ZXKeyWindow(void) {
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if ([s isKindOfClass:[UIWindowScene class]] && s.activationState == UISceneActivationStateForegroundActive) {
            for (UIWindow *x in ((UIWindowScene *)s).windows) if (x.isKeyWindow) return x;
        }
    }
    return nil;
}
static UIViewController *ZXTopVC(void) {
    UIViewController *v = ZXKeyWindow().rootViewController;
    while (v.presentedViewController) v = v.presentedViewController;
    return v;
}
static UIColor *ZXHex(uint32_t h) {
    return [UIColor colorWithRed:((h >> 16) & 0xFF) / 255.0 green:((h >> 8) & 0xFF) / 255.0 blue:(h & 0xFF) / 255.0 alpha:1];
}
static NSArray<UIColor *> *ZXRainbowUIColors(void) {
    return @[ZXHex(0xFF3B30), ZXHex(0xFF9500), ZXHex(0xFFCC00), ZXHex(0x34C759),
             ZXHex(0x0A84FF), ZXHex(0x5E5CE6), ZXHex(0xBF5AF2)];
}
static NSArray *ZXRainbowCG(void) {
    NSMutableArray *a = [NSMutableArray array];
    for (UIColor *c in ZXRainbowUIColors()) [a addObject:(id)c.CGColor];
    [a addObject:(id)ZXHex(0xFF3B30).CGColor]; // khép vòng
    return a;
}

// Viền 7 màu (đỏ, cam, vàng, lục, lam, chàm, tím), có thể xoay liên tục.
static CALayer *ZXRainbowBorder(CGSize size, CGFloat radius, CGFloat width, BOOL animate) {
    CALayer *host = [CALayer layer];
    host.frame = CGRectMake(0, 0, size.width, size.height);
    CGFloat d = hypot(size.width, size.height);
    CAGradientLayer *g = [CAGradientLayer layer];
    g.type = kCAGradientLayerConic;
    g.colors = ZXRainbowCG();
    g.startPoint = CGPointMake(0.5, 0.5);
    g.endPoint = CGPointMake(0.5, 0);
    g.bounds = CGRectMake(0, 0, d, d);
    g.position = CGPointMake(size.width / 2, size.height / 2);
    [host addSublayer:g];
    CAShapeLayer *m = [CAShapeLayer layer];
    m.frame = host.bounds;
    CGRect r = CGRectMake(width / 2, width / 2, size.width - width, size.height - width);
    m.path = [UIBezierPath bezierPathWithRoundedRect:r cornerRadius:MAX(0, radius - width / 2)].CGPath;
    m.fillColor = NULL;
    m.strokeColor = UIColor.blackColor.CGColor;
    m.lineWidth = width;
    host.mask = m;
    if (animate) {
        CABasicAnimation *a = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        a.fromValue = @0; a.toValue = @(M_PI * 2); a.duration = 4; a.repeatCount = HUGE_VALF;
        [g addAnimation:a forKey:@"spin"];
    }
    return host;
}

#pragma mark - Menu

@interface ZXMenuView : UIView
+ (void)show;
+ (void)hide;
@end
static ZXMenuView *gMenu;

@interface ZXFloatButton : UIView
@end
static ZXFloatButton *gFloat;

#pragma mark - Bảng thông tin: FPS, ngày giờ thực, RAM

static double ZXMemMB(void) {
    task_vm_info_data_t info;
    mach_msg_type_number_t c = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &c) == KERN_SUCCESS)
        return info.phys_footprint / 1048576.0;
    return 0;
}

static NSAttributedString *ZXRainbowText(NSString *t, UIFont *font) {
    NSMutableAttributedString *as = [[NSMutableAttributedString alloc] initWithString:t];
    NSArray *cols = ZXRainbowUIColors();
    for (NSUInteger i = 0; i < t.length; i++)
        [as addAttribute:NSForegroundColorAttributeName value:cols[i % cols.count] range:NSMakeRange(i, 1)];
    [as addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, t.length)];
    return as;
}

@interface ZXHud : UIView
- (void)start;
- (void)stop;
@end
static ZXHud *gHud;

@implementation ZXHud {
    UILabel *_info, *_credit;
    CADisplayLink *_link;
    CFTimeInterval _last;
    NSUInteger _frames;
    int _fps;
    NSDateFormatter *_df;
}
- (instancetype)init {
    self = [super initWithFrame:CGRectMake(10, 60, 150, 70)];
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.62];
    self.layer.cornerRadius = 12;
    self.layer.borderWidth = 1;
    self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.2].CGColor;
    _info = [UILabel new]; _info.numberOfLines = 0;
    _credit = [UILabel new];
    _credit.attributedText = ZXRainbowText(@"© Quang Bảo", [UIFont systemFontOfSize:10 weight:UIFontWeightHeavy]);
    [self addSubview:_info]; [self addSubview:_credit];
    _df = [NSDateFormatter new];
    _df.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    _df.dateFormat = @"dd/MM/yyyy HH:mm:ss";
    [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    [self refresh];
    return self;
}
- (void)start {
    if (_link) return;
    _last = 0; _frames = 0;
    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
    [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}
- (void)stop { [_link invalidate]; _link = nil; }
- (void)tick:(CADisplayLink *)l {
    if (_last == 0) { _last = l.timestamp; return; }
    _frames++;
    CFTimeInterval dt = l.timestamp - _last;
    if (dt >= 0.5) {
        _fps = (int)round(_frames / dt);
        _frames = 0; _last = l.timestamp;
        [self refresh];
    }
}
- (void)refresh {
    UIFont *f = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightSemibold];
    NSMutableAttributedString *out = [NSMutableAttributedString new];
    void (^add)(NSString *, UIColor *) = ^(NSString *line, UIColor *c) {
        if (out.length) [out appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n"]];
        [out appendAttributedString:[[NSAttributedString alloc] initWithString:line
            attributes:@{NSFontAttributeName: f, NSForegroundColorAttributeName: c}]];
    };
    if (ZXBool(@"hud_fps", YES)) {
        UIColor *c = _fps >= 55 ? ZXHex(0x34C759) : (_fps >= 40 ? ZXHex(0xFFCC00) : ZXHex(0xFF3B30));
        add([NSString stringWithFormat:@"FPS  %d", _fps], c);
    }
    if (ZXBool(@"hud_time", YES)) add([_df stringFromDate:[NSDate date]], UIColor.whiteColor);
    if (ZXBool(@"hud_mem", YES)) add([NSString stringWithFormat:@"RAM  %.0f MB", ZXMemMB()], UIColor.whiteColor);
    _info.attributedText = out;
    CGSize s1 = out.length ? [_info sizeThatFits:CGSizeMake(300, CGFLOAT_MAX)] : CGSizeZero;
    CGSize s2 = [_credit sizeThatFits:CGSizeMake(300, CGFLOAT_MAX)];
    CGFloat w = MAX(s1.width, s2.width) + 16;
    _info.frame = CGRectMake(8, 6, w - 16, s1.height);
    _credit.frame = CGRectMake(8, 6 + s1.height + (s1.height > 0 ? 2 : 0), w - 16, s2.height);
    CGRect fr = self.frame;
    fr.size = CGSizeMake(w, (_credit.frame.origin.y + _credit.frame.size.height) + 6);
    self.frame = fr;
}
- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *sv = self.superview; if (!sv) return;
    CGPoint t = [g translationInView:sv];
    CGPoint c = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    c.x = MIN(MAX(c.x, self.bounds.size.width / 2), sv.bounds.size.width - self.bounds.size.width / 2);
    c.y = MIN(MAX(c.y, self.bounds.size.height / 2), sv.bounds.size.height - self.bounds.size.height / 2);
    self.center = c;
    [g setTranslation:CGPointZero inView:sv];
}
- (void)dealloc { [_link invalidate]; }
@end

static void ZXSyncHud(UIWindow *w) {
    if (!ZXBool(@"hud_enabled", YES)) { [gHud stop]; [gHud removeFromSuperview]; gHud = nil; return; }
    if (!w) return;
    if (!gHud) {
        gHud = [ZXHud new];
        CGRect fr = gHud.frame; fr.origin = CGPointMake(10, w.safeAreaInsets.top + 8); gHud.frame = fr;
    }
    if (gHud.superview != w) [w addSubview:gHud];
    [gHud start];
    [w bringSubviewToFront:gHud];
}

// Biểu ngữ bản quyền hiện vài giây khi mở Zalo
static void ZXShowBanner(void) {
    UIWindow *w = ZXKeyWindow(); if (!w) return;
    UILabel *l = [UILabel new];
    l.attributedText = ZXRainbowText(@"ZaloXposed • by Quang Bảo", [UIFont systemFontOfSize:14 weight:UIFontWeightHeavy]);
    l.textAlignment = NSTextAlignmentCenter;
    l.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.92];
    l.layer.cornerRadius = 16; l.clipsToBounds = YES;
    l.userInteractionEnabled = NO;
    CGSize sz = [l sizeThatFits:CGSizeMake(320, 40)];
    l.frame = CGRectMake((w.bounds.size.width - sz.width - 32) / 2, w.safeAreaInsets.top + 6, sz.width + 32, 32);
    l.alpha = 0;
    [w addSubview:l];
    [UIView animateWithDuration:0.3 animations:^{ l.alpha = 1; } completion:^(BOOL f) {
        [UIView animateWithDuration:0.5 delay:2.5 options:0 animations:^{ l.alpha = 0; }
                         completion:^(BOOL f2) { [l removeFromSuperview]; }];
    }];
}

@interface ZXScreenBorder : UIView
@end
@implementation ZXScreenBorder {
    CALayer *_b;
    CGSize _last;
}
- (instancetype)init {
    self = [super initWithFrame:CGRectZero];
    self.userInteractionEnabled = NO; // không chặn thao tác chạm
    self.backgroundColor = UIColor.clearColor;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    if (_last.width == self.bounds.size.width && _last.height == self.bounds.size.height) return;
    _last = self.bounds.size;
    [_b removeFromSuperlayer];
    _b = ZXRainbowBorder(self.bounds.size, 47, 4, ZXBool(@"rainbow_anim", YES));
    [self.layer addSublayer:_b];
}
@end
static ZXScreenBorder *gBorder;
static void ZXSyncBorder(UIWindow *w) {
    if (!ZXBool(@"screen_border", YES)) { [gBorder removeFromSuperview]; gBorder = nil; return; }
    if (!w) return;
    if (!gBorder) gBorder = [ZXScreenBorder new];
    if (gBorder.superview != w) { gBorder.frame = w.bounds; [w addSubview:gBorder]; }
    [w bringSubviewToFront:gBorder];
}

static void ZXSyncFloat(void) {
    UIWindow *w = ZXKeyWindow();
    ZXSyncBorder(w);
    ZXSyncHud(w);
    BOOL want = ZXBool(@"floating_button", YES);
    if (!want) { [gFloat removeFromSuperview]; gFloat = nil; return; }
    if (!w) return;
    if (!gFloat) {
        gFloat = [ZXFloatButton new];
        gFloat.center = CGPointMake(w.bounds.size.width - 40, w.safeAreaInsets.top + 120);
    }
    if (gFloat.superview != w) [w addSubview:gFloat];
    [w bringSubviewToFront:gFloat];
    if (gMenu) [w bringSubviewToFront:gMenu];
}

@implementation ZXFloatButton
- (instancetype)init {
    self = [super initWithFrame:CGRectMake(0, 0, 54, 54)];
    self.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.92];
    self.layer.cornerRadius = 27;
    UILabel *l = [[UILabel alloc] initWithFrame:self.bounds];
    l.text = @"Z"; l.textAlignment = NSTextAlignmentCenter; l.textColor = UIColor.whiteColor;
    l.font = [UIFont systemFontOfSize:24 weight:UIFontWeightHeavy];
    [self addSubview:l];
    [self.layer addSublayer:ZXRainbowBorder(self.bounds.size, 27, 3, ZXBool(@"rainbow_anim", YES))];
    [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)]];
    [self addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)]];
    return self;
}
- (void)tap { if (gMenu) [ZXMenuView hide]; else [ZXMenuView show]; }
- (void)pan:(UIPanGestureRecognizer *)g {
    UIView *sv = self.superview; if (!sv) return;
    CGPoint t = [g translationInView:sv];
    UIEdgeInsets in = sv.safeAreaInsets;
    CGPoint c = CGPointMake(self.center.x + t.x, self.center.y + t.y);
    c.x = MIN(MAX(c.x, 27), sv.bounds.size.width - 27);
    c.y = MIN(MAX(c.y, in.top + 27), sv.bounds.size.height - in.bottom - 27);
    self.center = c;
    [g setTranslation:CGPointZero inView:sv];
    if (g.state == UIGestureRecognizerStateEnded) {
        CGFloat x = c.x < sv.bounds.size.width / 2 ? 33 : sv.bounds.size.width - 33;
        [UIView animateWithDuration:0.2 animations:^{ self.center = CGPointMake(x, c.y); }];
    }
}
@end

@implementation ZXMenuView {
    UIView *_panel;
    UIScrollView *_scroll;
    UIStackView *_stack;
    UIView *_pane;
    UITextView *_paneText;
    void (^_saveBlock)(NSString *);
}

+ (void)show {
    if (gMenu) return;
    UIWindow *w = ZXKeyWindow(); if (!w) return;
    ZXMenuView *m = [[ZXMenuView alloc] initWithFrame:w.bounds];
    gMenu = m;
    [w addSubview:m];
    m.alpha = 0;
    m->_panel.transform = CGAffineTransformMakeScale(0.92, 0.92);
    [UIView animateWithDuration:0.22 animations:^{
        m.alpha = 1; m->_panel.transform = CGAffineTransformIdentity;
    }];
}
+ (void)hide {
    ZXMenuView *m = gMenu; if (!m) return;
    gMenu = nil;
    [UIView animateWithDuration:0.18 animations:^{ m.alpha = 0; } completion:^(BOOL f) { [m removeFromSuperview]; }];
}

- (instancetype)initWithFrame:(CGRect)f {
    self = [super initWithFrame:f];
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

    UIView *dim = [[UIView alloc] initWithFrame:self.bounds];
    dim.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    dim.backgroundColor = [UIColor colorWithWhite:0 alpha:0.55];
    [dim addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:[ZXMenuView class] action:@selector(hide)]];
    [self addSubview:dim];

    CGFloat pw = MIN(f.size.width - 32, 400);
    CGFloat ph = MIN(f.size.height * 0.78, 640);
    _panel = [[UIView alloc] initWithFrame:CGRectMake((f.size.width - pw) / 2, (f.size.height - ph) / 2, pw, ph)];
    _panel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                              UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    _panel.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.98];
    _panel.layer.cornerRadius = 24;
    _panel.clipsToBounds = YES;
    [self addSubview:_panel];

    // Tiêu đề chữ 7 màu
    NSString *t = @"ZaloXposed";
    NSMutableAttributedString *as = [[NSMutableAttributedString alloc] initWithString:t];
    NSArray *cols = ZXRainbowUIColors();
    for (NSUInteger i = 0; i < t.length; i++)
        [as addAttribute:NSForegroundColorAttributeName value:cols[i % cols.count] range:NSMakeRange(i, 1)];
    [as addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:22 weight:UIFontWeightHeavy] range:NSMakeRange(0, t.length)];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(18, 10, pw - 80, 28)];
    title.attributedText = as;
    [_panel addSubview:title];
    UILabel *sub = [[UILabel alloc] initWithFrame:CGRectMake(18, 36, pw - 80, 16)];
    sub.text = [NSString stringWithFormat:@"%@ • by Quang Bảo", ZXL(@"settings_title", @"Menu cài đặt")]; sub.font = [UIFont systemFontOfSize:12];
    sub.textColor = [UIColor colorWithWhite:0.6 alpha:1];
    [_panel addSubview:sub];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(pw - 52, 10, 40, 40);
    [close setTitle:@"✕" forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    [close setTitleColor:[UIColor colorWithWhite:0.8 alpha:1] forState:UIControlStateNormal];
    [close addTarget:[ZXMenuView class] action:@selector(hide) forControlEvents:UIControlEventTouchUpInside];
    [_panel addSubview:close];

    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 60, pw, ph - 60)];
    _scroll.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _scroll.showsVerticalScrollIndicator = NO;
    [_panel addSubview:_scroll];
    _stack = [UIStackView new];
    _stack.axis = UILayoutConstraintAxisVertical;
    _stack.spacing = 8;
    _stack.translatesAutoresizingMaskIntoConstraints = NO;
    [_scroll addSubview:_stack];
    [NSLayoutConstraint activateConstraints:@[
        [_stack.topAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.topAnchor constant:6],
        [_stack.bottomAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.bottomAnchor constant:-16],
        [_stack.leadingAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.leadingAnchor constant:14],
        [_stack.trailingAnchor constraintEqualToAnchor:_scroll.contentLayoutGuide.trailingAnchor constant:-14],
        [_stack.widthAnchor constraintEqualToAnchor:_scroll.frameLayoutGuide.widthAnchor constant:-28],
    ]];
    [self buildContent];

    // Viền 7 màu (thêm sau cùng để nằm trên nội dung)
    [_panel.layer addSublayer:ZXRainbowBorder(CGSizeMake(pw, ph), 24, 3, ZXBool(@"rainbow_anim", YES))];
    return self;
}

#pragma mark Dựng nội dung

- (void)buildContent {
    [self addSection:@"Chống theo dõi" rows:@[
        [self toggleKey:@"disable_firebase" title:ZXL(@"logging_disable_firebase", @"Tắt Firebase Analytics")
                    sub:@"Không ghi và không gửi sự kiện phân tích" def:YES],
        [self toggleKey:@"block_hosts" title:@"Chặn theo tên miền"
                    sub:@"Chặn các máy chủ trong danh sách bên dưới" def:YES],
        [self buttonId:@"edit_hosts" title:@"✎  Sửa danh sách tên miền" color:ZXHex(0x0A84FF)],
    ]];
    [self addSection:@"Giao diện" rows:@[
        [self toggleKey:@"screen_border" title:@"Viền 7 màu quanh màn hình"
                    sub:@"Viền chạy quanh toàn bộ màn hình Zalo, không chặn thao tác chạm" def:YES],
        [self toggleKey:@"floating_button" title:@"Nút nổi"
                    sub:@"Nút Z kéo thả được để mở menu nhanh" def:YES],
        [self toggleKey:@"rainbow_anim" title:@"Viền 7 màu chuyển động"
                    sub:@"Áp dụng khi mở lại menu" def:YES],
    ]];
    [self addSection:@"Bảng thông tin" rows:@[
        [self toggleKey:@"hud_enabled" title:@"Bật bảng thông tin"
                    sub:@"Hiện góc màn hình, kéo thả được" def:YES],
        [self toggleKey:@"hud_fps" title:@"Đo FPS" sub:@"Xanh ≥55, vàng ≥40, đỏ thấp hơn" def:YES],
        [self toggleKey:@"hud_time" title:@"Ngày giờ thực" sub:@"Theo múi giờ của máy, cập nhật liên tục" def:YES],
        [self toggleKey:@"hud_mem" title:@"RAM đang dùng" sub:@"Bộ nhớ Zalo đang chiếm (MB)" def:YES],
    ]];
    [self addSection:@"Nhật ký" rows:@[
        [self toggleKey:@"log_enabled" title:@"Ghi nhật ký" sub:@"Lưu hoạt động chặn vào log.txt" def:YES],
        [self buttonId:@"log_view" title:@"☰  Xem nhật ký" color:ZXHex(0x0A84FF)],
        [self buttonId:@"log_export" title:@"⇪  Xuất nhật ký" color:ZXHex(0x0A84FF)],
        [self buttonId:@"log_clear" title:@"⌫  Xóa nhật ký" color:ZXHex(0xFF453A)],
    ]];
    [self addSection:@"Sắp ra mắt" rows:@[
        [self infoRow:@"• Tùy chỉnh thời gian sống tin nhắn\n• Gỡ giới hạn media\n• Gửi ảnh gốc mặc định\n(cần tên lớp/hàm của đúng bản Zalo)"],
    ]];
    [self addSection:@"Bản quyền" rows:@[
        [self infoRow:@"© 2026 Quang Bảo. Bảo lưu mọi quyền.\nThiết kế & phát triển: Quang Bảo.\nKhông sao chép, bán lại hoặc gỡ thông tin tác giả khi chưa được cho phép."],
    ]];
    [self addSection:@"Khác" rows:@[
        [self buttonId:@"reset" title:@"↺  Đặt lại mặc định" color:ZXHex(0xFF453A)],
        [self infoRow:@"ZaloXposed v2.1 • by Quang Bảo\nChạm 2 lần bằng 3 ngón trong Zalo để mở/đóng menu."],
    ]];
}

- (UIView *)toggleKey:(NSString *)key title:(NSString *)title sub:(NSString *)sub def:(BOOL)def {
    UILabel *t = [UILabel new]; t.text = title; t.textColor = UIColor.whiteColor; t.numberOfLines = 0;
    t.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    UILabel *s = [UILabel new]; s.text = sub; s.numberOfLines = 0;
    s.textColor = [UIColor colorWithWhite:0.65 alpha:1]; s.font = [UIFont systemFontOfSize:12];
    UIStackView *lab = [[UIStackView alloc] initWithArrangedSubviews:@[t, s]];
    lab.axis = UILayoutConstraintAxisVertical; lab.spacing = 2;
    UISwitch *sw = [UISwitch new];
    sw.on = ZXBool(key, def);
    sw.onTintColor = ZXHex(0x34C759);
    sw.accessibilityIdentifier = key;
    [sw addTarget:self action:@selector(toggled:) forControlEvents:UIControlEventValueChanged];
    [sw setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[lab, sw]];
    row.axis = UILayoutConstraintAxisHorizontal; row.alignment = UIStackViewAlignmentCenter; row.spacing = 12;
    return row;
}

- (UIView *)buttonId:(NSString *)ident title:(NSString *)title color:(UIColor *)c {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:c forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    b.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    b.accessibilityIdentifier = ident;
    [b addTarget:self action:@selector(tapped:) forControlEvents:UIControlEventTouchUpInside];
    [b.heightAnchor constraintEqualToConstant:34].active = YES;
    return b;
}

- (UIView *)infoRow:(NSString *)text {
    UILabel *l = [UILabel new]; l.text = text; l.numberOfLines = 0;
    l.textColor = [UIColor colorWithWhite:0.6 alpha:1]; l.font = [UIFont systemFontOfSize:12];
    return l;
}

- (void)addSection:(NSString *)title rows:(NSArray<UIView *> *)rows {
    UILabel *h = [UILabel new]; h.text = title.uppercaseString;
    h.textColor = [UIColor colorWithWhite:0.55 alpha:1];
    h.font = [UIFont systemFontOfSize:12 weight:UIFontWeightBold];
    [_stack addArrangedSubview:h];
    UIStackView *inner = [[UIStackView alloc] initWithArrangedSubviews:rows];
    inner.axis = UILayoutConstraintAxisVertical; inner.spacing = 12;
    inner.layoutMarginsRelativeArrangement = YES;
    inner.layoutMargins = UIEdgeInsetsMake(12, 14, 12, 14);
    inner.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *card = [UIView new];
    card.backgroundColor = [UIColor colorWithWhite:1 alpha:0.08];
    card.layer.cornerRadius = 14;
    [card addSubview:inner];
    [NSLayoutConstraint activateConstraints:@[
        [inner.topAnchor constraintEqualToAnchor:card.topAnchor],
        [inner.bottomAnchor constraintEqualToAnchor:card.bottomAnchor],
        [inner.leadingAnchor constraintEqualToAnchor:card.leadingAnchor],
        [inner.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],
    ]];
    [_stack addArrangedSubview:card];
    [_stack setCustomSpacing:18 afterView:card];
}

#pragma mark Hành động

- (void)toggled:(UISwitch *)sw {
    NSString *k = sw.accessibilityIdentifier;
    ZXSetBool(k, sw.on);
    ZXLog(@"%@ = %d", k, sw.on);
    if ([k isEqualToString:@"floating_button"] || [k isEqualToString:@"screen_border"] || [k hasPrefix:@"hud_"]) ZXSyncFloat();
}

- (void)tapped:(UIButton *)b {
    NSString *a = b.accessibilityIdentifier;
    if ([a isEqualToString:@"edit_hosts"]) {
        [self showPaneTitle:@"Tên miền bị chặn" text:[ZXHosts() componentsJoinedByString:@"\n"]
                   editable:YES onSave:^(NSString *txt) {
            NSMutableArray *out = [NSMutableArray array];
            NSCharacterSet *sep = [NSCharacterSet characterSetWithCharactersInString:@",\n "];
            for (NSString *s in [txt componentsSeparatedByCharactersInSet:sep]) {
                NSString *h = [s stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
                if (h.length) [out addObject:h];
            }
            [[NSUserDefaults standardUserDefaults] setObject:out forKey:@"ZX_hosts"];
        }];
    } else if ([a isEqualToString:@"log_view"]) {
        NSString *t = [NSString stringWithContentsOfFile:ZXLogPath() encoding:NSUTF8StringEncoding error:nil];
        [self showPaneTitle:ZXL(@"log_view", @"Nhật ký") text:(t.length ? t : ZXL(@"log_empty", @"Chưa có nhật ký"))
                   editable:NO onSave:nil];
    } else if ([a isEqualToString:@"log_export"]) {
        [self exportLog];
    } else if ([a isEqualToString:@"log_clear"]) {
        [@"" writeToFile:ZXLogPath() atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self toast:ZXL(@"log_cleared", @"Đã xóa nhật ký")];
    } else if ([a isEqualToString:@"reset"]) {
        NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
        for (NSString *k in [[ud dictionaryRepresentation] allKeys])
            if ([k hasPrefix:kPrefix]) [ud removeObjectForKey:k];
        ZXSyncFloat();
        [ZXMenuView hide];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [ZXMenuView show]; });
    }
}

- (void)exportLog {
    UIViewController *top = ZXTopVC(); if (!top) return;
    UIActivityViewController *vc = [[UIActivityViewController alloc]
        initWithActivityItems:@[[NSURL fileURLWithPath:ZXLogPath()]] applicationActivities:nil];
    vc.popoverPresentationController.sourceView = top.view;
    vc.popoverPresentationController.sourceRect = CGRectMake(top.view.bounds.size.width / 2, 100, 1, 1);
    self.hidden = YES;
    vc.completionWithItemsHandler = ^(UIActivityType t, BOOL ok, NSArray *r, NSError *e) { self.hidden = NO; };
    [top presentViewController:vc animated:YES completion:nil];
}

- (void)toast:(NSString *)text {
    UILabel *l = [[UILabel alloc] init];
    l.text = [NSString stringWithFormat:@"  %@  ", text];
    l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    l.backgroundColor = [UIColor colorWithWhite:0 alpha:0.85];
    l.layer.cornerRadius = 14; l.clipsToBounds = YES;
    [l sizeToFit];
    CGRect fr = l.frame; fr.size.height = 30;
    fr.origin = CGPointMake((_panel.bounds.size.width - fr.size.width) / 2, _panel.bounds.size.height - 54);
    l.frame = fr;
    l.alpha = 0;
    [_panel addSubview:l];
    [UIView animateWithDuration:0.2 animations:^{ l.alpha = 1; } completion:^(BOOL f) {
        [UIView animateWithDuration:0.3 delay:1.2 options:0 animations:^{ l.alpha = 0; }
                         completion:^(BOOL f2) { [l removeFromSuperview]; }];
    }];
}

#pragma mark Trang con (xem log / sửa tên miền)

- (void)showPaneTitle:(NSString *)title text:(NSString *)text editable:(BOOL)ed onSave:(void (^)(NSString *))save {
    [_pane removeFromSuperview];
    UIView *p = [[UIView alloc] initWithFrame:_scroll.frame];
    p.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    p.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];
    CGFloat w = p.bounds.size.width, h = p.bounds.size.height;

    UIButton *back = [UIButton buttonWithType:UIButtonTypeSystem];
    back.frame = CGRectMake(10, 0, 110, 44);
    [back setTitle:@"‹ Quay lại" forState:UIControlStateNormal];
    back.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [back addTarget:self action:@selector(closePane) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:back];

    UILabel *tl = [[UILabel alloc] initWithFrame:CGRectMake(110, 0, w - 220, 44)];
    tl.text = title; tl.textAlignment = NSTextAlignmentCenter; tl.textColor = UIColor.whiteColor;
    tl.font = [UIFont systemFontOfSize:15 weight:UIFontWeightBold];
    [p addSubview:tl];

    UITextView *tv = [[UITextView alloc] initWithFrame:CGRectMake(10, 44, w - 20, h - 44 - 10)];
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tv.backgroundColor = [UIColor colorWithWhite:1 alpha:0.06];
    tv.textColor = UIColor.whiteColor;
    tv.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    tv.layer.cornerRadius = 12;
    tv.editable = ed;
    tv.text = text;
    tv.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tv.autocorrectionType = UITextAutocorrectionTypeNo;
    [p addSubview:tv];
    _paneText = tv;

    if (ed) {
        _saveBlock = [save copy];
        UIButton *sv = [UIButton buttonWithType:UIButtonTypeSystem];
        sv.frame = CGRectMake(w - 80, 0, 70, 44);
        sv.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
        [sv setTitle:ZXL(@"button_save", @"Lưu") forState:UIControlStateNormal];
        sv.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightBold];
        [sv addTarget:self action:@selector(savePane) forControlEvents:UIControlEventTouchUpInside];
        [p addSubview:sv];
    }
    [_panel addSubview:p];
    _pane = p;
    // đưa viền lên trên cùng
    for (CALayer *ly in [_panel.layer.sublayers copy]) {
        if (ly.mask && ly.sublayers.count == 1 && [ly.sublayers.firstObject isKindOfClass:[CAGradientLayer class]]) {
            [ly removeFromSuperlayer]; [_panel.layer addSublayer:ly];
        }
    }
}
- (void)closePane { [_pane removeFromSuperview]; _pane = nil; _saveBlock = nil; [self endEditing:YES]; }
- (void)savePane {
    if (_saveBlock) _saveBlock(_paneText.text);
    [self closePane];
    [self toast:ZXL(@"toast_saved", @"Đã lưu cài đặt")];
}
@end

#pragma mark - Cách mở menu: chạm 2 lần bằng 3 ngón (hoặc nút nổi)

@interface ZXTrigger : NSObject
+ (instancetype)shared; - (void)attach; - (void)open;
@end
@implementation ZXTrigger
+ (instancetype)shared { static ZXTrigger *t; static dispatch_once_t o; dispatch_once(&o, ^{ t = [ZXTrigger new]; }); return t; }
- (void)attach {
    for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
        if (![s isKindOfClass:[UIWindowScene class]]) continue;
        for (UIWindow *w in ((UIWindowScene *)s).windows) {
            if (objc_getAssociatedObject(w, "zx_attached")) continue;
            UITapGestureRecognizer *g = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(open)];
            g.numberOfTapsRequired = 2; g.numberOfTouchesRequired = 3; g.cancelsTouchesInView = NO;
            [w addGestureRecognizer:g];
            objc_setAssociatedObject(w, "zx_attached", @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
    }
    ZXSyncFloat();
    static BOOL shown = NO;
    if (!shown && ZXKeyWindow()) { shown = YES; ZXShowBanner(); }
}
- (void)open { if (gMenu) [ZXMenuView hide]; else [ZXMenuView show]; }
@end

#pragma mark - Khởi tạo

__attribute__((constructor)) static void ZXInit(void) {
    ZXLog(@"ZaloXposed v2.1 by Quang Bao loaded in %@", NSBundle.mainBundle.bundleIdentifier);
    ZXInstallHooks();
    NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
    void (^again)(NSNotification *) = ^(NSNotification *n) {
        ZXInstallHooks();
        [[ZXTrigger shared] attach];
    };
    [nc addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
    [nc addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:again];
}
