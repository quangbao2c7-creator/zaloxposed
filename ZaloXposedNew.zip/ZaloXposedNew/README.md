# ZaloXposed (bản mới)

## Build không cần Mac
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên.
2. Vào tab Actions → "Build dylib" → Run workflow.
3. Tải artifact `ZaloXposed` → lấy `ZaloXposed.dylib`.

## Gắn vào app
Dùng Sideloadly (Advanced Options → Inject dylibs) hoặc Azule/TrollStore để chèn `ZaloXposed.dylib` vào IPA Zalo.
`ZaloXposedRes.bundle` là tùy chọn (chuỗi VI/EN); không có thì dùng tiếng Việt mặc định.

## Dùng
Chạm 2 lần bằng 3 ngón trong Zalo để mở Cài đặt.
Log nằm ở Documents/ZaloXposed/log.txt.
