# ZaloXposed v2.1 — by Quang Bảo
© 2026 Quang Bảo. Bảo lưu mọi quyền.

## Tính năng
- Menu viền 7 màu chuyển động, nút nổi Z kéo thả được.
- Viền 7 màu quanh toàn màn hình Zalo.
- Bảng thông tin: FPS, ngày giờ thực, RAM.
- Tắt Firebase Analytics, chặn theo tên miền (sửa danh sách trong menu).
- Nhật ký: xem, xuất, xóa.

## Build không cần Mac
Đẩy lên GitHub → Actions → "Build dylib" → tải artifact `ZaloXposed`.

## Mở menu
Bấm nút Z, hoặc chạm 2 lần bằng 3 ngón trong Zalo.
